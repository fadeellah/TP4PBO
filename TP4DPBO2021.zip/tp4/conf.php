<?php

/******************************************
PRAKTIKUM RPL
 ******************************************/

// Konfigurasi basis data

$db_host = "localhost"; // host 
$db_user = "root"; // user
$db_password = ""; // password
$db_name = "db_task"; // nama basis data

 ?>