<?php 

/******************************************
PRAKTIKUM RPL
******************************************/

class Task extends DB{
	
	// Mengambil data
	function getTask(){
		// Query mysql select data ke tb_to_do
		$query = "SELECT * FROM tb_to_do";

		// Mengeksekusi query
		return $this->execute($query);
	}

	function insert($data)
	{
		$tname = $data['tname'];
		$tdetails = $data ['tdetails'];
		$tsubject = $data['tsubject'];
		$tpriority = $data['tpriority'];
		$tdeadline = $data['tdeadline'];
		$tstatus = "belum";

		$query = "INSERT INTO tb_to_do (name_td, details_td, subject_td, priority_td, deadline_td, status_td) VALUES ( '$tname', '$tdetails', '$tsubject', '$tpriority', '$tdeadline', '$tstatus')";

		return $this->execute($query); 
	}
	
	function delete($id)
	{
		$query = "DELETE FROM tb_to_do WHERE id = {$id}";

		// mengeksekusi query
		$this->execute($query); 
	}
	
	function update($id){
		$query = "UPDATE tb_to_do SET status_td = 'Sudah' Where id = {$id}";
		$this->execute($query);
	}

}




?>
